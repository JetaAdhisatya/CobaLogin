<?php echo e($slot); ?>

<?php /**PATH C:\D_Drive\tugassekolah\Binus Sem5\Web Prog\Laravel Project\login\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>